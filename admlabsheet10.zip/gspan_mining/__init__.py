from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from .gspan import gSpan


__version__ = '0.2.2'
